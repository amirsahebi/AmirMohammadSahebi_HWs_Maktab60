from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(College)
admin.site.register(CollegeLesson)
admin.site.register(Classes)
admin.site.register(Lesson)
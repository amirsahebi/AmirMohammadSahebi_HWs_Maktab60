from django.contrib import admin
from log.models import Email_log

# Register your models here.

admin.site.register(Email_log)
